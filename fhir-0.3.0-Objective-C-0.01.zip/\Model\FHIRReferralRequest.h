﻿/*
  Copyright (c) 2011-2014, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Sat, Aug 9, 2014 07:35+1000 for FHIR v0.3.0
 */
/*
 * A request for referral or tranfer of care
 *
 * [FhirResource("ReferralRequest")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRCode;
@class FHIRIdentifier;
@class FHIRCodeableConcept;
@class FHIRResource;
@class FHIRDateTime;
@class FHIRString;
@class FHIRPeriod;

@interface FHIRReferralRequest : FHIRBaseResource

/*
 * The status of the referral
 */
typedef enum 
{
    kReferralStatusDraft, // A draft referral that has yet to be send.
    kReferralStatusSent, // The referral has been transmitted, but not yet acknowledged by the recipient.
    kReferralStatusActive, // The referral has been acknowledged by the recipient, and is in the process of being actioned.
    kReferralStatusCancelled, // The referral has been cancelled without being completed. For example it is no longer needed.
    kReferralStatusRefused, // The recipient has declined to accept the referral.
    kReferralStatusCompleted, // The referral has been completely actioned.
} kReferralStatus;

/*
 * draft | sent | active | cancelled | refused | completed
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kReferralStatus status;

/*
 * Identifier of request
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * Referral/Transition of care request type
 */
@property (nonatomic, strong) FHIRCodeableConcept *type;

/*
 * The clinical specialty (discipline) that the referral is requested for
 */
@property (nonatomic, strong) FHIRCodeableConcept *specialty;

/*
 * Urgency of referral / transfer of care request
 */
@property (nonatomic, strong) FHIRCodeableConcept *priority;

/*
 * Patient/subject of referral or care transfer request
 */
@property (nonatomic, strong) FHIRResource *subject;

/*
 * Requester of referral / transfer of care
 */
@property (nonatomic, strong) FHIRResource *requester;

/*
 * Receiver of referral / transfer of care request
 */
@property (nonatomic, strong) NSArray/*<ResourceReference>*/ *recipient;

/*
 * Encounter
 */
@property (nonatomic, strong) FHIRResource *encounter;

/*
 * Date referral/transfer of care request is sent
 */
@property (nonatomic, strong) FHIRDateTime *dateSentElement;

@property (nonatomic, strong) NSString *dateSent;

/*
 * Reason for referral / Transfer of care request
 */
@property (nonatomic, strong) FHIRCodeableConcept *reason;

/*
 * A textual description of the referral
 */
@property (nonatomic, strong) FHIRString *descriptionElement;

@property (nonatomic, strong) NSString *description;

/*
 * Service(s) requested
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *serviceRequested;

/*
 * Additonal information to support referral or transfer of care request
 */
@property (nonatomic, strong) NSArray/*<ResourceReference>*/ *supportingInformation;

/*
 * Requested service(s) fulfillment time
 */
@property (nonatomic, strong) FHIRPeriod *fulfillmentTime;

- (FHIRErrorList *)validate;

@end
