﻿/*
  Copyright (c) 2011-2014, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Sat, Aug 9, 2014 07:35+1000 for FHIR v0.3.0
 */
/*
 * Definition of an operation or a named query
 *
 * [FhirResource("OperationDefinition")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRUri;
@class FHIRString;
@class FHIRContact;
@class FHIRCoding;
@class FHIRCode;
@class FHIRBoolean;
@class FHIRDateTime;
@class FHIRResource;
@class FHIROperationDefinitionParameterComponent;

@interface FHIROperationDefinition : FHIRBaseResource

/*
 * Whether an operation parameter is an input or an output parameter
 */
typedef enum 
{
    kOperationParameterUseIn, // This is an input parameter.
    kOperationParameterUseOut, // This is an output parameter.
} kOperationParameterUse;

/*
 * Whether an operation is a normal operation or a query
 */
typedef enum 
{
    kOperationKindOperation, // This operation is invoked as an operation.
    kOperationKindQuery, // This operation is a named query, invoked using the search mechanism.
} kOperationKind;

/*
 * Logical id to reference this operation definition
 */
@property (nonatomic, strong) FHIRUri *identifierElement;

@property (nonatomic, strong) NSString *identifier;

/*
 * Logical id for this version of the operation definition
 */
@property (nonatomic, strong) FHIRString *versionElement;

@property (nonatomic, strong) NSString *version;

/*
 * Informal name for this profile
 */
@property (nonatomic, strong) FHIRString *titleElement;

@property (nonatomic, strong) NSString *title;

/*
 * Name of the publisher (Organization or individual)
 */
@property (nonatomic, strong) FHIRString *publisherElement;

@property (nonatomic, strong) NSString *publisher;

/*
 * Contact information of the publisher
 */
@property (nonatomic, strong) NSArray/*<Contact>*/ *telecom;

/*
 * Natural language description of the operation
 */
@property (nonatomic, strong) FHIRString *descriptionElement;

@property (nonatomic, strong) NSString *description;

/*
 * Assist with indexing and finding
 */
@property (nonatomic, strong) NSArray/*<Coding>*/ *code;

/*
 * draft | active | retired
 */
@property (nonatomic, strong) FHIRCode *statusElement;

@property (nonatomic, strong) NSString *status;

/*
 * If for testing purposes, not real usage
 */
@property (nonatomic, strong) FHIRBoolean *experimentalElement;

@property (nonatomic, strong) NSNumber *experimental;

/*
 * Date for this version of the operation definition
 */
@property (nonatomic, strong) FHIRDateTime *dateElement;

@property (nonatomic, strong) NSString *date;

/*
 * operation | query
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *kindElement;

@property (nonatomic) kOperationKind kind;

/*
 * Name used to invoke the operation
 */
@property (nonatomic, strong) FHIRCode *nameElement;

@property (nonatomic, strong) NSString *name;

/*
 * Additional information about use
 */
@property (nonatomic, strong) FHIRString *notesElement;

@property (nonatomic, strong) NSString *notes;

/*
 * Marks this as a profile of the base
 */
@property (nonatomic, strong) FHIRResource *base_;

/*
 * Invoke at the system level?
 */
@property (nonatomic, strong) FHIRBoolean *systemElement;

@property (nonatomic, strong) NSNumber *system;

/*
 * Invoke at resource level for these type
 */
@property (nonatomic, strong) NSArray/*<code>*/ *typeElement;

@property (nonatomic, strong) NSArray /*<NSString>*/ *type;

/*
 * Invoke on an instance?
 */
@property (nonatomic, strong) FHIRBoolean *instanceElement;

@property (nonatomic, strong) NSNumber *instance;

/*
 * Parameters for the operation/query
 */
@property (nonatomic, strong) NSArray/*<OperationDefinitionParameterComponent>*/ *parameter;

- (FHIRErrorList *)validate;

@end
