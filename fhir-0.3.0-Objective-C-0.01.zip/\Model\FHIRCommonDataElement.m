﻿/*
  Copyright (c) 2011-2014, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Fri, May 16, 2014 11:44+1000 for FHIR v0.2.1
 */
/*
 * Resource Observation Definition
 */
#import "FHIRCommonDataElement.h"

#import "FHIRString.h"
#import "FHIRContact.h"
#import "FHIRCode.h"
#import "FHIRDateTime.h"
#import "FHIRCodeableConcept.h"
#import "FHIRCoding.h"
#import "FHIRElement.h"
#import "FHIRInteger.h"
#import "FHIRCommonDataElementBindingComponent.h"
#import "FHIRCommonDataElementMappingComponent.h"

#import "FHIRErrorList.h"

@implementation FHIRCommonDataElement

- (NSString *)identifier
{
    if(self.identifierElement)
    {
        return [self.identifierElement value];
    }
    return nil;
}

- (void )setIdentifier:(NSString *)identifier
{
    if(identifier)
    {
        [self setIdentifierElement:[[FHIRString alloc] initWithValue:identifier]];
    }
    else
    {
        [self setIdentifierElement:nil];
    }
}


- (NSString *)version
{
    if(self.versionElement)
    {
        return [self.versionElement value];
    }
    return nil;
}

- (void )setVersion:(NSString *)version
{
    if(version)
    {
        [self setVersionElement:[[FHIRString alloc] initWithValue:version]];
    }
    else
    {
        [self setVersionElement:nil];
    }
}


- (NSString *)publisher
{
    if(self.publisherElement)
    {
        return [self.publisherElement value];
    }
    return nil;
}

- (void )setPublisher:(NSString *)publisher
{
    if(publisher)
    {
        [self setPublisherElement:[[FHIRString alloc] initWithValue:publisher]];
    }
    else
    {
        [self setPublisherElement:nil];
    }
}


- (kResourceCommonDataElementStatus )status
{
    return [FHIREnumHelper parseString:[self.statusElement value] enumType:kEnumTypeResourceCommonDataElementStatus];
}

- (void )setStatus:(kResourceCommonDataElementStatus )status
{
    [self setStatusElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:status enumType:kEnumTypeResourceCommonDataElementStatus]]];
}


- (NSString *)date
{
    if(self.dateElement)
    {
        return [self.dateElement value];
    }
    return nil;
}

- (void )setDate:(NSString *)date
{
    if(date)
    {
        [self setDateElement:[[FHIRDateTime alloc] initWithValue:date]];
    }
    else
    {
        [self setDateElement:nil];
    }
}


- (NSString *)name
{
    if(self.nameElement)
    {
        return [self.nameElement value];
    }
    return nil;
}

- (void )setName:(NSString *)name
{
    if(name)
    {
        [self setNameElement:[[FHIRString alloc] initWithValue:name]];
    }
    else
    {
        [self setNameElement:nil];
    }
}


- (NSString *)question
{
    if(self.questionElement)
    {
        return [self.questionElement value];
    }
    return nil;
}

- (void )setQuestion:(NSString *)question
{
    if(question)
    {
        [self setQuestionElement:[[FHIRString alloc] initWithValue:question]];
    }
    else
    {
        [self setQuestionElement:nil];
    }
}


- (NSString *)definition
{
    if(self.definitionElement)
    {
        return [self.definitionElement value];
    }
    return nil;
}

- (void )setDefinition:(NSString *)definition
{
    if(definition)
    {
        [self setDefinitionElement:[[FHIRString alloc] initWithValue:definition]];
    }
    else
    {
        [self setDefinitionElement:nil];
    }
}


- (NSString *)comments
{
    if(self.commentsElement)
    {
        return [self.commentsElement value];
    }
    return nil;
}

- (void )setComments:(NSString *)comments
{
    if(comments)
    {
        [self setCommentsElement:[[FHIRString alloc] initWithValue:comments]];
    }
    else
    {
        [self setCommentsElement:nil];
    }
}


- (NSString *)requirements
{
    if(self.requirementsElement)
    {
        return [self.requirementsElement value];
    }
    return nil;
}

- (void )setRequirements:(NSString *)requirements
{
    if(requirements)
    {
        [self setRequirementsElement:[[FHIRString alloc] initWithValue:requirements]];
    }
    else
    {
        [self setRequirementsElement:nil];
    }
}


- (NSArray /*<NSString>*/ *)synonym
{
    if(self.synonymElement)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(FHIRString *elem in self.synonymElement)
            [array addObject:[elem value]];
        return [NSArray arrayWithArray:array];
    }
    return nil;
}

- (void )setSynonym:(NSArray /*<NSString>*/ *)synonym
{
    if(synonym)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(NSString *value in synonym)
            [array addObject:[[FHIRString alloc] initWithValue:value]];
        [self setSynonymElement:[NSArray arrayWithArray:array]];
    }
    else
    {
        [self setSynonymElement:nil];
    }
}


- (NSString *)type
{
    if(self.typeElement)
    {
        return [self.typeElement value];
    }
    return nil;
}

- (void )setType:(NSString *)type
{
    if(type)
    {
        [self setTypeElement:[[FHIRCode alloc] initWithValue:type]];
    }
    else
    {
        [self setTypeElement:nil];
    }
}


- (NSNumber *)maxLength
{
    if(self.maxLengthElement)
    {
        return [self.maxLengthElement value];
    }
    return nil;
}

- (void )setMaxLength:(NSNumber *)maxLength
{
    if(maxLength)
    {
        [self setMaxLengthElement:[[FHIRInteger alloc] initWithValue:maxLength]];
    }
    else
    {
        [self setMaxLengthElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifierElement != nil )
        [result addValidationRange:[self.identifierElement validate]];
    if(self.versionElement != nil )
        [result addValidationRange:[self.versionElement validate]];
    if(self.publisherElement != nil )
        [result addValidationRange:[self.publisherElement validate]];
    if(self.telecom != nil )
        for(FHIRContact *elem in self.telecom)
            [result addValidationRange:[elem validate]];
    if(self.statusElement != nil )
        [result addValidationRange:[self.statusElement validate]];
    if(self.dateElement != nil )
        [result addValidationRange:[self.dateElement validate]];
    if(self.nameElement != nil )
        [result addValidationRange:[self.nameElement validate]];
    if(self.category != nil )
        for(FHIRCodeableConcept *elem in self.category)
            [result addValidationRange:[elem validate]];
    if(self.code != nil )
        for(FHIRCoding *elem in self.code)
            [result addValidationRange:[elem validate]];
    if(self.questionElement != nil )
        [result addValidationRange:[self.questionElement validate]];
    if(self.definitionElement != nil )
        [result addValidationRange:[self.definitionElement validate]];
    if(self.commentsElement != nil )
        [result addValidationRange:[self.commentsElement validate]];
    if(self.requirementsElement != nil )
        [result addValidationRange:[self.requirementsElement validate]];
    if(self.synonymElement != nil )
        for(FHIRString *elem in self.synonymElement)
            [result addValidationRange:[elem validate]];
    if(self.typeElement != nil )
        [result addValidationRange:[self.typeElement validate]];
    if(self.example != nil )
        [result addValidationRange:[self.example validate]];
    if(self.maxLengthElement != nil )
        [result addValidationRange:[self.maxLengthElement validate]];
    if(self.units != nil )
        [result addValidationRange:[self.units validate]];
    if(self.binding != nil )
        [result addValidationRange:[self.binding validate]];
    if(self.mapping != nil )
        for(FHIRCommonDataElementMappingComponent *elem in self.mapping)
            [result addValidationRange:[elem validate]];
    
    return result;
}

@end
