﻿/*
  Copyright (c) 2011-2014, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Thu, Jul 31, 2014 15:46+1000 for FHIR v0.2.1
 */
/*
 * A human or software device that uses the system
 */
#import "FHIRSecurityPrincipal.h"

#import "FHIRIdentifier.h"
#import "FHIRHumanName.h"
#import "FHIRString.h"
#import "FHIRAttachment.h"
#import "FHIRContact.h"
#import "FHIRBase64Binary.h"
#import "FHIRInteger.h"
#import "FHIRResource.h"
#import "FHIRSecurityPrincipalClaimComponent.h"

#import "FHIRErrorList.h"

@implementation FHIRSecurityPrincipal

- (NSString *)description
{
    if(self.descriptionElement)
    {
        return [self.descriptionElement value];
    }
    return nil;
}

- (void )setDescription:(NSString *)description
{
    if(description)
    {
        [self setDescriptionElement:[[FHIRString alloc] initWithValue:description]];
    }
    else
    {
        [self setDescriptionElement:nil];
    }
}


- (NSString *)login
{
    if(self.loginElement)
    {
        return [self.loginElement value];
    }
    return nil;
}

- (void )setLogin:(NSString *)login
{
    if(login)
    {
        [self setLoginElement:[[FHIRString alloc] initWithValue:login]];
    }
    else
    {
        [self setLoginElement:nil];
    }
}


- (NSData *)passwordHash
{
    if(self.passwordHashElement)
    {
        return [self.passwordHashElement value];
    }
    return nil;
}

- (void )setPasswordHash:(NSData *)passwordHash
{
    if(passwordHash)
    {
        [self setPasswordHashElement:[[FHIRBase64Binary alloc] initWithValue:passwordHash]];
    }
    else
    {
        [self setPasswordHashElement:nil];
    }
}


- (NSArray /*<NSString>*/ *)ipMask
{
    if(self.ipMaskElement)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(FHIRString *elem in self.ipMaskElement)
            [array addObject:[elem value]];
        return [NSArray arrayWithArray:array];
    }
    return nil;
}

- (void )setIpMask:(NSArray /*<NSString>*/ *)ipMask
{
    if(ipMask)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(NSString *value in ipMask)
            [array addObject:[[FHIRString alloc] initWithValue:value]];
        [self setIpMaskElement:[NSArray arrayWithArray:array]];
    }
    else
    {
        [self setIpMaskElement:nil];
    }
}


- (NSNumber *)sessionLength
{
    if(self.sessionLengthElement)
    {
        return [self.sessionLengthElement value];
    }
    return nil;
}

- (void )setSessionLength:(NSNumber *)sessionLength
{
    if(sessionLength)
    {
        [self setSessionLengthElement:[[FHIRInteger alloc] initWithValue:sessionLength]];
    }
    else
    {
        [self setSessionLengthElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.name != nil )
        for(FHIRHumanName *elem in self.name)
            [result addValidationRange:[elem validate]];
    if(self.descriptionElement != nil )
        [result addValidationRange:[self.descriptionElement validate]];
    if(self.photo != nil )
        [result addValidationRange:[self.photo validate]];
    if(self.contact != nil )
        for(FHIRContact *elem in self.contact)
            [result addValidationRange:[elem validate]];
    if(self.loginElement != nil )
        [result addValidationRange:[self.loginElement validate]];
    if(self.passwordHashElement != nil )
        [result addValidationRange:[self.passwordHashElement validate]];
    if(self.ipMaskElement != nil )
        for(FHIRString *elem in self.ipMaskElement)
            [result addValidationRange:[elem validate]];
    if(self.sessionLengthElement != nil )
        [result addValidationRange:[self.sessionLengthElement validate]];
    if(self.resource != nil )
        for(FHIRResource *elem in self.resource)
            [result addValidationRange:[elem validate]];
    if(self.claim != nil )
        for(FHIRSecurityPrincipalClaimComponent *elem in self.claim)
            [result addValidationRange:[elem validate]];
    if(self.group != nil )
        for(FHIRResource *elem in self.group)
            [result addValidationRange:[elem validate]];
    
    return result;
}

@end
