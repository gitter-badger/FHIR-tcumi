package org.hl7.fhir.instance.model;

public class Constants {

  public final static String VERSION = "0.0.81";
  public final static String REVISION = "2382";
  public final static String DATE = "Fri May 09 11:14:37 EST 2014";
}
